# ideogram-extension
An extension of the rice ideogram (http://snp-seek.irri.org/_ideo.zul;jsessionid=BF6CB4143B6D4547B2D05DD50F9CD3FC?tracks=DNA,msu7gff,msu7snpsv2,msu7indelsv2&amp;app=rice-ideogram)
